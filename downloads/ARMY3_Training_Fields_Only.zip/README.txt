ARMY3 打靶／單戰／跨欄精簡場景

來源：Vmylife/ARMY3/main 的 shooting-user-scene.json（Git blob f6b150d97101ef3d61dd3911389687acc8339d39）
原版場景保持不變。

保留：靶場靶架 6、靶場告示牌 1、跨欄 5、單戰場木箱 11、沙包 10、桶子 12、靶場附近圍欄 14；共 59 個物件。
刪除：其餘 214 個建築及物件，包括 12 棟建築、玩家後加的紅桶與高塔、其他圍欄、樹木、花草、球框、路燈等。

使用說明：
1. 開啟 https://vmylife.github.io/ARMY3/shooting-scene-editor.html
2. 點「匯入 JSON」，選擇 shooting-training-fields-only.json。
3. 編輯器會將它匯入成新場景，原有場景不覆蓋。
4. 可繼續編輯、匯出 shooting-user-scene.json；若要取代打靶遊戲，才自行將匯出檔上傳到 ARMY3。

注意：道路、草地、操場、籃球場、其他區域的彩色地面等是程式生成的底圖，不屬於 JSON 物件；這份精簡場景只清除所有其他可編輯物件，不會修改底圖生成器。
